<?php
session_start();

$servername = "localhost"; // Change if your server is different
$db_username = "root"; // Your database username
$db_password = "saroot123"; // Your database password
$dbname = "sms";
$pdo = new PDO("mysql:servername=$servername;dbname=$dbname", $db_username, $db_password);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}


// Fetch messages
$stmt = $pdo->prepare("SELECT distinct * FROM messages WHERE recipient_id = ? OR sender_id = ?  order by id asc");
//$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
$messages = $stmt->fetchAll();



try {
    // Create a new PDO instance
    $pdo1 = new PDO("mysql:servername=$servername;dbname=$dbname", $db_username, $db_password);
    $pdo1->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$id = $_SESSION['user_id'];
    // Query to fetch data from the items table
    //$stmt_1 = $pdo1->query("SELECT distinct username FROM users");
    //$itemsAdd = $stmt_1->fetchAll(PDO::FETCH_ASSOC);
	
	$stmt_1 = $pdo1->query("SELECT distinct id,username FROM users where id != $id  order by id asc");
	//$stmt_1->execute($_SESSION['user_id']);
	$items = $stmt_1->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Connection failed[username]: " . $e->getMessage();
    exit;
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Real-Time Chatbot</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .chat { border: 1px solid #ccc; padding: 10px; height: 300px; overflow-y: scroll; }
        .message { margin: 5px; }
    </style>
</head>
<body>
<div class="chat-container">
		<h2>Welcome, <div id="session_user_id"><?php  echo $_SESSION['user_id'];  ?></div><div id="session_username"> <?php echo $_SESSION['username']; ?></div></h2>
  <!--  <div id="messages">
        <?php foreach ($messages as $message): ?>
            <div class="message <?php echo $message['sender_id'] == $_SESSION['user_id'] ? 'sent' : 'received'; ?>">
                <strong><?php echo $message['sender_id']; ?>:</strong> <?php echo htmlspecialchars($message['message']); ?>
                <em><?php echo $message['created_at']; ?></em>
            </div>
        <?php endforeach; ?>
    </div> -->
	
    <input type="hidden" id="suId_user_id" name="suId_user_id" value="<?php  echo $_SESSION['user_id'];  ?>">
   


    <div id="chat"></div>
	<div  id="result"></div>  <!--<input type="text" id="p1" name="p1" value=""> hidden ;style="display:none"-->
	<select id="itemSelect" name="item_id" onchange="selectItem()"> <!--onchange="selectItem()-->
	<option value="">--Select a user--</option>
		<?php foreach ($items as $item): ?>
			<option value="<?php echo htmlspecialchars($item['id']); ?>">
					<?php echo htmlspecialchars($item['username']); ?>
		    </option>
        <?php endforeach; ?>
	</select>      
	<div  id="p2"></div> 
	
	<!--<input type="hidden" id="rs_id" name="rs_id" value="">
	-->
    
	<input type="text" id="message" placeholder="Type a message...">
    <button id="send" >Send</button>  <!--onclick="getSelectedValue()"-->
	
    <script>
	/*
		function getDivId() {
            var div = document.getElementById('session_username').value;
            alert(div);
        }
	*/	
	function getSelectedValue()
	{
		var cookieValue = document.getElementById("result").getAttribute('value');
		//document.getElementById("p1") = cookieValue.innerText;
		//$_SESSION['recipientId'] =cookieValue;
		//alert('p1:'+document.getElementById("p1").getAttribute('value') );
		//alert ('result:'+ cookieValue);
	}
	
	/*
	onclick="getDivValue()"
		function getDivValue() {
			// Get the div element by its ID
			var div = document.getElementById('session_username');
			
			// Get the text content of the div
			var value = div.textContent; // or div.innerHTML for HTML content
			
			// Display the value (for example, in an alert)
			alert(value);
		}
	*/
	
			function selectItem() {
            // Get the dropdown and textbox elements
				var dropdown = document.getElementById("itemSelect");
			  //  var textbox = document.getElementById("myTextbox1");
			
  			   //it work
			  	//var textbox = document.getElementById("rs_id");
				document.getElementById("result").innerText  = dropdown.value;
				//textbox.value = dropdown.value;
				var element1 = document.createElement("input");
				element1.type = "hidden";
				element1.value = dropdown.value;
				//document.getElementById("result").appendChild(element1);
				 //  document.getElementById("result").innerText =element1.value;
				//alert('element1.value'+element1.value);	
			     var a = document.getElementById("result").appendChild(element1);
				//document.getElementById("p2").innerText  = a; 
				// Set the textbox value to the selected option's value
			
				//document.getElementById("p2").innerText =a;
				//alert('a:'+a);
				//alert('p2:'+document.getElementById("p2").innerText);
				//var p2 = document.getElementById.bind(result);
				//console.log(p2('p2'));
			 
			
				//alert(element1.value);
			}
/*	
		   function getSelectedValue() {
				var dropdown = document.getElementById("itemSelect");
				var selectedValue = dropdown.options[dropdown.selectedIndex].value;
				document.getElementById("result").innerText = "Selected Value: " + selectedValue;  //maybe assign to a hidden value or a new div id
			}
*/
			//	const senderId = 1; // Replace with dynamic user ID
			//	const recipientId = 2; // Replace with dynamic recipient ID
			var su_id = document.getElementById('session_user_id');	
			var su_idValue = su_id.textContent; 
		//	alert('su_idValue'+su_idValue);
			//var ru_id = document.ElementById('session_recipientId');
		
			//var ru_id = document.getElementById("result");
			//alert('element1.value:'+ element1.value);
			//alert(document.getElementById("result").textContent);
			//alert(document.getElementById("result").innerText );
			//var b =  a.textContent //document.getElementById("result");
			//var b = ru_id; 		   
		    //alert('b:'+b);
			//var ru_idValue = ru_id.textContent; 
			//alert('ru_idValue'+ru_idValue);
		
			const senderId = su_idValue; // Replace with dynamic user ID
			//alert('senderId'+senderId);
			var recipientId ="";
		    //const recipientId = a.getAttribute('value');
		
			//var ru_id =document.getElementById("result");//.getAttribute('value');//document.getElementById("rs_id").appendChild(element1); //document.getElementById("rs_id").innerText; //textbox.value; //
			//recipientId = ru_id.getAttribute('value');
			//alert('ru_id:'+ru_id);	
			//alert('recipientId'+recipientId);	
			document.getElementById('send').onclick = function() {
			getSelectedValue();
			var a = document.getElementById("result");
			recipientId = a.textContent;
		//------------------------------------------------------------
		
			var div = document.getElementById('session_username');
			// Get the text content of the div
			var value = div.textContent; // or div.innerHTML for HTML content
			// alert(value);
		//   var div = document.getElementById('session_username').value;
           // alert(div);
		
		    var message = document.getElementById('message').value;
			value += ':' + message;
			//alert(value);
            fetch('send_message.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          //      body: `sender_id=${senderId}&recipient_id=${recipientId}&message=${encodeURIComponent(message)}`
		          body: `sender_id=${senderId}&recipient_id=${recipientId}&message=${encodeURIComponent(value)}`
	      
			}).then(() => {
                document.getElementById('message').value = '';
                loadMessages();
            });
        };

		//get message
        function loadMessages() {
			
		    fetch(`get_messages.php?sender_id=${senderId}&recipient_id=${recipientId}`)
                .then(response => response.json())
                .then(messages => {
                    const chat = document.getElementById('chat');
                    chat.innerHTML = '';
                    messages.forEach(msg => {
                        const div = document.createElement('div');
                        div.className = 'message';
                        div.textContent = `${msg.sender_id}: ${msg.message} (${msg.created_at})`;
                        chat.appendChild(div);
                    });
                });
			
				//alert("test");
        }

		function func() {
			let time = new Date().toLocaleTimeString();
			var run_1 = loadMessages();
	    }
	  
		// Refresh messages every 2 seconds
		//var func = loadMessages();
		var run_2 = setInterval(func,2000);



       //
	   // setInterval("loadMessages",2000);
	   /*
		setInterval(() => {
			let time = new Date().toLocaleTimeString();
			document.querySelector(‘h1’).innerHTML = time;
			loadMessages();
			}, 2000);
			*/
		
    </script>
</body>
</html>