<?php
$servername = "localhost"; // Change if your server is different
$db_username = "root"; // Your database username
$db_password = "saroot123"; // Your database password
$dbname = "sms";

$pdo = new PDO("mysql:servername=$servername;dbname=$dbname", $db_username, $db_password);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users (username, role, password) VALUES (?, ?, ?)");
    $stmt->execute([$username, $role, $password]);

    echo "User registered!";
	header("Location: login.php");
}
?>
<form method="POST">
    Username: <input type="text" name="username" required>
    Role: <select name="role">
        <option value="guest">Guest</option>
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
    </select>
    Password: <input type="password" name="password" required>
    <button type="submit">Register</button>
</form>