

    <?php
	$system='sys';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection
        $servername = "localhost"; // Change if your server is different
		$username = "root"; // Your database username
		$password = "saroot123"; // Your database password
		$dbname = "sms";


        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

		// Set parameters and execute
        $student_id = $_POST['student_id'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $date_of_birth = $_POST['date_of_birth'];
        $gender = $_POST['gender'];
        $gradelevel = $_POST['gradelevel'];
        $address = $_POST['address'];
        $phoneNumber = $_POST['phoneNumber'];
        $guardian_info = $_POST['guardian_info'];
		$db_create_user = $system;
		$db_update_user = $system;

        // Prepare and bind
       	$stmt = $conn->prepare("INSERT INTO student (student_id,firstName,lastName,dateOfBirth,gender,gradelevel,address,phoneNumber,guardian_info,db_create_user,db_update_user) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssssss", $student_id, $first_name, $last_name, $date_of_birth, $gender, $gradelevel, $address, $phoneNumber, $guardian_info ,$db_create_user ,$db_update_user);

        if ($stmt->execute()) {
           // echo "New signed up successfully!";
		   echo '<script>alert("New signed up successfully!")</script>';
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close connections
        $stmt->close();
        $conn->close();
    }
    ?>
