<?php
if (isset($_GET['option'])) {
    $option = $_GET['option'];
    switch ($option) {
        case 'Teacher':
     	    echo '<form action="signupTForm.php" method="post">
				<input type="text" name="teacher_id" placeholder="Teacher ID" required>
				<input type="text" name="first_name" placeholder="First Name" required>
				<input type="text" name="last_name" placeholder="Last Name" required>
				<input type="date" name="date_of_birth" placeholder="Date of Birth" required>
				<select name="gender" required>
					<option value="">Select Gender</option>
					<option value="Male">Male</option>
					<option value="Female">Female</option>
					<option value="Other">Other</option>
				</select>
				<input type="text" name="qualification" placeholder="Qualification">
				<input type="number" name="working_experience" placeholder="Years of Experience" min="0">
				<input type="text" name="department" placeholder="Department">
				<input type="text" name="phone_number" placeholder="Phone Number" required>
				<input type="email" name="email_address" placeholder="Email Address" required>
			    <button type="submit">Sign Up</button>
				</form>';
            break;
        case 'Student':
     	    echo '<form action="signupSForm.php" method="post">
				<input type="text" name="student_id" placeholder="student ID" required>
				<input type="text" name="first_name" placeholder="First Name" required>
				<input type="text" name="last_name" placeholder="Last Name" required>
				<input type="date" name="date_of_birth" placeholder="Date of Birth" required>
				<select name="gender" required>
					<option value="">Select Gender</option>
					<option value="Male">Male</option>
					<option value="Female">Female</option>
					<option value="Other">Other</option>
				</select>
				<input type="text" name="gradelevel" placeholder="Grade level" required> 
				<input type="text" name="address" placeholder="Address" required>
				<input type="number" name="phoneNumber" placeholder="Phone Number" required>
				<input type="text" name="guardian_info" placeholder="Guardian Info" required>
			    <button type="submit">Sign Up</button>
				</form>';
            break;
        case 'Staff':
     	    echo '<form action="signupGForm.php" method="post">
				<input type="text" name="user_code" placeholder="User code" required>
				<input type="text" name="user_name" placeholder="User Name" required>
				<input type="text" name="user_password" placeholder="User Password" required>
				<input type="email" name="user_email_addr" placeholder="user_email_addr" required>
				<select name="user_role" required>
					<option value="">Select position</option>
					<option value="Manager">Manager</option>
					<option value="Staff">Staff</option>
					<option value="Other">Other</option>
				</select>
			    <button type="submit">Sign Up</button>
				</form>';
            break;
        default:
            echo 'Invalid option selected.';
    }
} else {
    echo 'No option selected.';
}
?>