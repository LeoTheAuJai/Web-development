

    <?php
	$system='sys';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection
        $servername = "localhost"; // Change if your server is different
		$username = "root"; // Your database username
		$password = "saroot123"; // Your database password
		$dbname = "sms";


        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

		// Set parameters and execute
        $teacher_id = $_POST['teacher_id'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $date_of_birth = $_POST['date_of_birth'];
        $gender = $_POST['gender'];
        $qualification = $_POST['qualification'];
        $working_experience = $_POST['working_experience'];
        $department = $_POST['department'];
        $phone_number = $_POST['phone_number'];
        $email_address = $_POST['email_address'];
		$db_create_user = $system;
		$db_update_user = $system;

        // Prepare and bind
       	$stmt = $conn->prepare("INSERT INTO teacher (teacher_id,firstName,lastName,dateOfBirth,gender,qualification,exp,dept,phone_num,email_addr,db_create_user,db_update_user) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssssss", $teacher_id, $first_name, $last_name, $date_of_birth, $gender, $qualification, $working_experience, $department, $phone_number, $email_address ,$db_create_user ,$db_update_user);

        if ($stmt->execute()) {
           // echo "New signed up successfully!";
		   echo '<script>alert("New signed up successfully!")</script>';
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close connections
        $stmt->close();
        $conn->close();
    }
    ?>
