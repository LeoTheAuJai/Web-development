

    <?php
	$system='sys';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection
        $servername = "localhost"; // Change if your server is different
		$username = "root"; // Your database username
		$password = "saroot123"; // Your database password
		$dbname = "sms";


        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

		// Set parameters and execute
        $user_code = $_POST['user_code'];
        $user_name = $_POST['user_name'];
        $user_password = $_POST['user_password'];
        $user_email_addr = $_POST['user_email_addr'];
        $user_role = $_POST['user_role'];
     	$db_create_user = $system;
		$db_update_user = $system;

        // Prepare and bind
       	$stmt = $conn->prepare("INSERT INTO usermain (user_code,user_name,user_password,user_email_addr,user_role,db_create_user,db_update_user) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $user_code, $user_name, $user_password, $user_email_addr, $user_role,$db_create_user ,$db_update_user);

        if ($stmt->execute()) {
           // echo "New signed up successfully!";
		   echo '<script>alert("New signed up successfully!")</script>';
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close connections
        $stmt->close();
        $conn->close();
    }
    ?>
