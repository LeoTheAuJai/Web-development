package gameconsole;
import java.util.Scanner;

public class GameConsole {

public static void main(String[] args) {
        System.out.println("=============================================");
        System.out.println("Group members:");
        System.out.println("SID: StudentID 1 Name: Group Member's Name 1");
        System.out.println("SID: StudentID 2 Name: Group Member's Name 2");
        System.out.println("SID: StudentID 3 Name: Group Member's Name 3");
        System.out.println("=============================================");
        System.out.println("Welcome to the Game Console: A Trio of Classic Games!");
        System.out.println("Please select a game to play:");
        System.out.println("1. Tic Tac Toe");
        System.out.println("2. Hangman");
        System.out.println("3. Number Guessing");
        System.out.println("Enter the corresponding number (1-3) or enter 'q' to quit:");

        Scanner scanner = new Scanner(System.in);
        String input = scanner.next();

        switch (input) {
            case "1":
                System.out.println("You have selected Tic Tac Toe");
                TicTacToe Game1 = new TicTacToe();
                Game1.run();
                break;
            case "2":
                System.out.println("You have selected Hangman");
                Hangman Game2 = new Hangman();
                Game2.run();
                break;
            case "3":
                System.out.println("You have selected Number Guessing");
                NumberGuessing Game3 = new NumberGuessing();
                Game3.run();
                break;
            case "q":
                System.out.println("Thank you for playing!");
                break;
            default:
                System.out.println("Invalid input, please enter a number (1-3) or 'q' to quit.");
                break;
        }

        scanner.close();
    }
    
}
