package gameconsole;

public class TicTacToe {
    public static void run() {
        System.out.println("Main Program of Tic Tac Toe");
    }
}
