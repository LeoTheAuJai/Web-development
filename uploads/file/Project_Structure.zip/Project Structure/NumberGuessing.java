package gameconsole;

public class NumberGuessing {
    public static void run() {
        System.out.println("Main Program of Number Guessing Game");
    }        
}
