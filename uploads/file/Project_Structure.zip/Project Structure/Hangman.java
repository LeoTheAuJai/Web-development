package gameconsole;

public class Hangman {
    public static void run() {
        System.out.println("Main Program of Hangman");
    }    
}
