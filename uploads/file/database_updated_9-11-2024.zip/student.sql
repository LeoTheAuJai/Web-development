-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- 主機: 127.0.0.1
-- 產生時間： 2024-11-09 06:34:55
-- 伺服器版本: 5.7.17
-- PHP 版本： 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `sms`
--

-- --------------------------------------------------------

--
-- 資料表結構 `student`
--

CREATE TABLE `student` (
  `s_id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `dateOfBirth` varchar(10) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `gradelevel` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(20) DEFAULT NULL,
  `guardian_info` varchar(50) DEFAULT NULL,
  `create_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  `modify_dt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `db_create_user` varchar(20) DEFAULT NULL,
  `db_update_user` varchar(20) DEFAULT NULL,
  `fk_user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 資料表的匯出資料 `student`
--

INSERT INTO `student` (`s_id`, `student_id`, `firstName`, `lastName`, `dateOfBirth`, `gender`, `gradelevel`, `address`, `phoneNumber`, `guardian_info`, `create_dt`, `modify_dt`, `db_create_user`, `db_update_user`, `fk_user_id`) VALUES
(8, 'awdawdaw', 'dwadwa', 'wadwada', 'wdadwa', 'wdawd', 'awdwa', 'awdwa', '22', 'wdaa', '2024-11-09 01:42:22', '2024-11-09 01:42:22', '11', '22', 12345696),
(9, 'awdawdaw', 'dwadwa', 'wadwada', 'wdadwa', 'wdawd', 'awdwa', 'awdwa', '22', 'wdaa', '2024-11-09 01:42:24', '2024-11-09 01:42:24', '11', '22', 12345696);

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`s_id`,`student_id`);

--
-- 在匯出的資料表使用 AUTO_INCREMENT
--

--
-- 使用資料表 AUTO_INCREMENT `student`
--
ALTER TABLE `student`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
