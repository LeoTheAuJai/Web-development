-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- 主機: 127.0.0.1
-- 產生時間： 2024-11-09 06:33:53
-- 伺服器版本: 5.7.17
-- PHP 版本： 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `sms`
--

-- --------------------------------------------------------

--
-- 資料表結構 `studentworks`
--

CREATE TABLE `studentworks` (
  `sw_id` int(11) NOT NULL,
  `logo_name` varchar(50) NOT NULL,
  `logo_type` varchar(10) NOT NULL,
  `file_name` varchar(50) DEFAULT NULL,
  `file_type` varchar(10) DEFAULT NULL,
  `title` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `create_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  `modify_dt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `author_name` varchar(20) DEFAULT NULL,
  `author_user_ID` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 資料表的匯出資料 `studentworks`
--

INSERT INTO `studentworks` (`sw_id`, `logo_name`, `logo_type`, `file_name`, `file_type`, `title`, `description`, `create_dt`, `modify_dt`, `author_name`, `author_user_ID`) VALUES
(7, 'image__1_.png', 'png', 'msg_20241105_2045_.zip', 'zip', 'title1', '14', '2024-11-09 13:29:31', '2024-11-09 13:29:31', '123456', '12345696'),
(6, 'Untitled_design.png', 'png', 'msg_20241105_2045_.zip', 'zip', 'title1', '14', '2024-11-09 13:27:01', '2024-11-09 13:27:01', '123456', '12345696'),
(5, 'Untitled_design.png', 'png', 'signup.zip', 'zip', 'title1', '14', '2024-11-09 13:26:25', '2024-11-09 13:26:25', '123456', '12345696');

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `studentworks`
--
ALTER TABLE `studentworks`
  ADD PRIMARY KEY (`sw_id`);

--
-- 在匯出的資料表使用 AUTO_INCREMENT
--

--
-- 使用資料表 AUTO_INCREMENT `studentworks`
--
ALTER TABLE `studentworks`
  MODIFY `sw_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
